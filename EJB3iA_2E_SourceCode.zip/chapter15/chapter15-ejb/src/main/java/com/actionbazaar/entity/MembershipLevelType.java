package com.actionbazaar.entity;

public enum MembershipLevelType {

	BRONZE, GOLD, SILVER, PLATINUM
}
