/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.actionbazaar.account;

/**
 *
 * @author rcuprak
 */
public class Summary {

    private int bids;
    
    private int bidsWon;
    
    public Summary(int bids, int bidsWon) {
        this.bids = bids;
        this.bidsWon = bidsWon; 
    }
    
}
