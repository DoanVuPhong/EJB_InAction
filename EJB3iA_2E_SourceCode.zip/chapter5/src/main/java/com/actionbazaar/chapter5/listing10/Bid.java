package com.actionbazaar.chapter5.listing10;

public interface Bid {

}
