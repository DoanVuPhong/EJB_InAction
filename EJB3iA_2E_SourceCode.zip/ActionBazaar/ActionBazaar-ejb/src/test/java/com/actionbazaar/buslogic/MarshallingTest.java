/**
 *  EJB 3 in Action
 *  Book: http://manning.com/panda2/
 *  Code: http://code.google.com/p/action-bazaar/
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */
package com.actionbazaar.buslogic;

/**
 * Tests JAXB Marshalling. If JAXB classes aren't marshalling correctly, then we
 * have problems when deploying a JAX-WS webservice.
 * @author Ryan Cuprak
 */
public class MarshallingTest {

    /*
    
    
    @Test
    public void testBidderMarshalling () throws Exception {
        Bidder bidder = new Bidder();
        JAXBContext ctx = JAXBContext.newInstance(Bidder.class);
        StringWriter writer = new StringWriter();
        ctx.createMarshaller().marshal(bidder,writer);



        String test = writer.toString();
        System.out.println("Output: " + test);
    }

    @Test
    public void testBidMarshalling() throws Exception {
        Address address = new Address("149 Arizona 64","Tusayan", State.Arizona,"86023","(888) 634-7263");
        BillingInfo bi = new CreditCard("Ryan Cuprak","","06","2012","055", CreditCardType.MASTERCARD);
        Bidder bidder = new Bidder("rcuprak","password","ryan","cuprak",bi,address,new Date(),true);
        Item item = new Item("Death in the Grand Canyon",new Date(),new Date(),new BigDecimal("10.00"));
        
        Bid bid = new Bid(bidder,item,new BigDecimal("10.55")); 
        StringWriter writer = new StringWriter();
        JAXBContext ctx = JAXBContext.newInstance(Bid.class);
        ctx.createMarshaller().marshal(bid,writer);
        String test = writer.toString();
        System.out.println("Output: " + test);
        // TODO need to implement equals on these classes
        
    }
    */

}
