package com.actionbazaar.buslogic;

/**
 * Created by IntelliJ IDEA.
 * User: rcuprak
 * Date: 2/12/12
 * Time: 8:00 PM
 * To change this template use File | Settings | File Templates.
 */
public class Newsletter {
}
