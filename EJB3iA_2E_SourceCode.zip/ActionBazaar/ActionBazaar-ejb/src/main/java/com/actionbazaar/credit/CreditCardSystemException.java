package com.actionbazaar.credit;

import javax.ejb.ApplicationException;

/**
 * Created by IntelliJ IDEA.
 * User: rcuprak
 * Date: 5/8/11
 * Time: 11:49 PM
 * To change this template use File | Settings | File Templates.
 */
@ApplicationException(rollback=true)
public class CreditCardSystemException extends RuntimeException {
}
