package com.actionbazaar.buslogic;

/**
 * Created by IntelliJ IDEA.
 * User: rcuprak
 * Date: 8/20/11
 * Time: 1:53 PM
 * To change this template use File | Settings | File Templates.
 */
public class OrderService {
}
