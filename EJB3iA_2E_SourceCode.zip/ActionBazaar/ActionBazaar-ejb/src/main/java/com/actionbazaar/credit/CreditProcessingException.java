package com.actionbazaar.credit;

import javax.ejb.ApplicationException;

@ApplicationException(rollback=true)
public class CreditProcessingException extends Exception {

    public CreditProcessingException(String message) {
        super(message);
    }
}
